package com.example.vrok.seattracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class ClearActivity extends ChangeStatusAbstract {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activityNo = STATUS_CHECKIN;
        setBtn_ChangeStatus("Empty Seat");
    }

    //sets status to empty (0)
    public void saveStatusToPreferences(int row, int column){
        mEditor.putInt("key_seat_status_row"+String.valueOf(row)+"_column_"+String.valueOf(column),STATUS_EMPTY);
    }

    @Override
    public void getIndividualSeatStatus() {
        status = getStatusFromPreferences(rowNo-1,seatNo-1);
        msgTitle = "Empty seat?";
        msg = String.format("Seat %d in Row %d will be set to empty.",rowNo,seatNo);
        msgAccept = String.format("Set as empty: Row %d Seat %d",rowNo,seatNo);
        msgEmpty = String.format("Seat %d in Row %d is empty.",rowNo,seatNo);
    }

    @Override
    public void getAllSeatsStatus() {
        msgTitle = "Empty all seats?";
        msg = "This will set all seats to empty. Are you sure?";
        msgAccept = "All seats are set to empty.";
        msgEmpty = "All seats are empty.";
    }

    @Override
    public void getColumnSeatsStatus() {
        msgTitle = String.format("Empty seats in Column %d?",seatNo);
        msg = String.format("This will set all seats in Column %d to empty.",seatNo);
        msgAccept = String.format("All seats in Column %d are set to empty.", seatNo);
        msgEmpty = String.format("All seats in Column %d are empty.",seatNo);
    }

    @Override
    public void getRowSeatsStatus() {
        msgTitle = String.format("Empty seats in Row %d?",rowNo);
        msg = String.format("This will set all seats in Row %d to empty.",rowNo);
        msgAccept = String.format("All seats in Row %d are set to empty.", rowNo);
        msgEmpty = String.format("All seats in Row %d are empty.",rowNo);
    }

    @Override
    public boolean getStatusByActivity(int status) {return (status != STATUS_EMPTY);}

    @Override
    public void confirmMessage(AlertDialog.Builder alert) {
        switch (status){
            case 0: Toast.makeText(this,msgEmpty,Toast.LENGTH_SHORT).show(); break;
            default: alert.show(); break;
        }
    }

    public void btn_ChangeStatus_Clicked(View view){
        status = 2;
        super.btn_ChangeStatus_Clicked(view);
    }
}
