package com.example.vrok.seattracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public abstract class ChangeStatusAbstract extends ActivityAbstract implements AdapterView.OnItemSelectedListener {
    //spinner attributes
    private Spinner sp_RowNo;
    private Spinner sp_SeatNo;
    private Button btn_View;
    private Button btn_ChangeStatus;
    private ArrayList<String> rowList;
    private ArrayList<String> seatNoList;

    //values for keeping track of activity and selected row and seat numbers
    int activityNo;
    int rowNo;
    int seatNo;

    //check status attributes and messages
    int status;
    String msgTitle = "";
    String msg = "";
    String msgEmpty = "";
    String msgBooked = "";
    String msgCheckedIn = "";
    String msgAccept = "";
    int emptyCount = 0;
    int bookedCount = 0;
    int checkedInCount = 0;
    int seatCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_status_abstract);

        sp_RowNo = (Spinner)findViewById(R.id.sp_RowNo);
        rowList = new ArrayList<>();
        for(int i = 0; i <= seatRow; i++)
            if(i < seatRow)
                rowList.add(String.valueOf(i+1));
            else
                rowList.add("All");

        ArrayAdapter<String> adapter_Row = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, rowList);
        adapter_Row.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_RowNo.setAdapter(adapter_Row);
        sp_RowNo.setOnItemSelectedListener(this);

        sp_SeatNo = (Spinner)findViewById(R.id.sp_SeatNo);
        seatNoList = new ArrayList<>();
        for(int i = 0; i <= seatColumn; i++)
            if(i < seatColumn)
                seatNoList.add(String.valueOf(i+1));
            else
                seatNoList.add("All");

        ArrayAdapter<String> adapter_Seat = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, seatNoList);
        adapter_Seat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_SeatNo.setAdapter(adapter_Seat);
        sp_SeatNo.setOnItemSelectedListener(this);

        btn_View = (Button)findViewById(R.id.btn_View);
        btn_View.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ChangeStatusAbstract.this, SummaryActivity.class);
                startActivity(i);
            }
        });

        btn_ChangeStatus = (Button)findViewById(R.id.btn_ChangeStatus);
    }

    public void setBtn_ChangeStatus(String label){
        btn_ChangeStatus.setText(label);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.sp_RowNo:
                if(parent.getItemAtPosition(position).toString() != "All")
                    rowNo = Integer.parseInt(parent.getItemAtPosition(position).toString());
                else
                    rowNo = 0;
                break;
            case R.id.sp_SeatNo:
                if(parent.getItemAtPosition(position).toString() != "All")
                    seatNo = Integer.parseInt(parent.getItemAtPosition(position).toString());
                else
                    seatNo = 0;
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public abstract void saveStatusToPreferences(int row, int column);

    public abstract void getIndividualSeatStatus();
    public abstract void getAllSeatsStatus();
    public abstract void getColumnSeatsStatus();
    public abstract void getRowSeatsStatus();
    public abstract boolean getStatusByActivity(int status);
    public abstract void confirmMessage(AlertDialog.Builder alert);

    public int determineStatusForMultipleSeats(){
        if(emptyCount == seatCount)
            return 0;
        if(bookedCount == seatCount)
            return 1;
        if(checkedInCount == seatCount)
            return 2;

        return activityNo;
    }

    public void btn_ChangeStatus_Clicked(View view){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        if (rowNo != 0 && seatNo != 0) {
            getIndividualSeatStatus();
        }
        else{
            emptyCount = 0;
            bookedCount = 0;
            checkedInCount = 0;
            seatCount = 0;

            if(rowNo == 0 && seatNo == 0){
                for(int i = 0; i < seatRow; i++)
                    for(int j = 0; j < seatColumn; j++) {
                        switch (getStatusFromPreferences(i,j)){
                            case 0: emptyCount++; break;
                            case 1: bookedCount++; break;
                            case 2: checkedInCount++; break;
                        }
                        seatCount++;
                    }
                getAllSeatsStatus();
            }
            else{
                if(rowNo == 0){
                    for(int i = 0; i < seatRow; i++) {
                        switch (getStatusFromPreferences(i,seatNo-1)){
                            case 0: emptyCount++; break;
                            case 1: bookedCount++; break;
                            case 2: checkedInCount++; break;
                        }
                        seatCount++;
                    }
                    getColumnSeatsStatus();
                }
                if(seatNo == 0){
                    for(int i = 0; i < seatColumn; i++) {
                        switch (getStatusFromPreferences(rowNo-1,i)){
                            case 0: emptyCount++; break;
                            case 1: bookedCount++; break;
                            case 2: checkedInCount++; break;
                        }
                        seatCount++;
                    }
                    getRowSeatsStatus();
                }
            }
            status = determineStatusForMultipleSeats();
        }

        alert.setTitle(msgTitle);
        alert.setMessage(msg);
        final String finalMsgAccept = msgAccept;
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (rowNo != 0 && seatNo != 0) {
                    saveStatusToPreferences(rowNo-1,seatNo-1);
                }
                else {
                    if (rowNo == 0 && seatNo == 0) {
                        for(int i = 0; i < seatRow; i++)
                            for(int j = 0; j < seatColumn; j++) {
                                if (getStatusByActivity(getStatusFromPreferences(i,j)))
                                    saveStatusToPreferences(i,j);
                            }
                    }
                    else{
                        if(rowNo == 0){
                            for(int i = 0; i < seatRow; i++)
                                if(getStatusByActivity(getStatusFromPreferences(i,seatNo-1)))
                                    saveStatusToPreferences(i,seatNo-1);
                        }
                        if(seatNo == 0){
                            for(int i = 0; i < seatColumn; i++)
                                if(getStatusByActivity(getStatusFromPreferences(rowNo-1,i)))
                                    saveStatusToPreferences(rowNo-1,i);
                        }
                    }
                }
                mEditor.commit();
                Toast.makeText(ChangeStatusAbstract.this, finalMsgAccept,Toast.LENGTH_SHORT).show();
                Intent i = new Intent(ChangeStatusAbstract.this, SummaryActivity.class);
                startActivity(i);
            }
        });
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        confirmMessage(alert);
    }
}
