package com.example.vrok.seattracker;

import java.io.Serializable;

public class Seat implements Serializable {
    private int status;
    private int rowNo;
    private int seatNo;

    public Seat(){
        status = 0;
    }

    public void setRowNo(int rowNo) {
        this.rowNo = rowNo;
    }

    public void setSeatNo(int seatNo) {
        this.seatNo = seatNo;
    }

    public void setToEmpty() {status = 0;}
    public void setToBooked() {status = 1;}
    public void setToCheckIn() {status = 2;}

    public int getStatus() {return status;}
}
