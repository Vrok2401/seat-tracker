package com.example.vrok.seattracker;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public abstract class ActivityAbstract extends AppCompatActivity {
    //shared preferences
    SharedPreferences mPreferences;
    SharedPreferences.Editor mEditor;

    //static values for seat status
    protected static final int STATUS_EMPTY = 0;
    protected static final int STATUS_BOOKED = 1;
    protected static final int STATUS_CHECKIN = 2;

    //saved values for seat rows and columns
    int seatRow = 0;
    int seatColumn = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //prepare shared preferences
        PreferenceManager.setDefaultValues(this,R.xml.preferences,false);
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        seatRow = Integer.parseInt(mPreferences.getString("key_row","5"));
        seatColumn = Integer.parseInt(mPreferences.getString("key_column","10"));
        mEditor = mPreferences.edit();
    }

    //load status from references
    public int getStatusFromPreferences(int row, int column){
        return mPreferences.getInt("key_seat_status_row"+String.valueOf(row)+"_column_"+String.valueOf(column),0);
    }
}
