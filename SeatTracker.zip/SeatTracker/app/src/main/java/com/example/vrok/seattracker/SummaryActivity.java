package com.example.vrok.seattracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class SummaryActivity extends ActivityAbstract {
    private TextView txt_SeatSummary;
    private ImageView img_seatTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        txt_SeatSummary = (TextView)findViewById(R.id.txt_SeatSummary);

        //get table of seats as an image
        img_seatTable = (ImageView)findViewById(R.id.img_seatTable);
        Bitmap seatTable = drawSeatTable();
        img_seatTable.setImageBitmap(seatTable);

        //initialise seat status counters
        int emptyCount = 0;
        int bookedCount = 0;
        int checkedInCount = 0;


        //seat status counters
        for(int i = 0; i < seatRow; i++){
            for(int j = 0; j < seatColumn; j++) {
                switch(getStatusFromPreferences(i,j)){
                    case 0: emptyCount++; break;
                    case 1: bookedCount++; break;
                    case 2: checkedInCount++; break;
                }
            }
        }

        String summary = String.format("Empty seats:\t%3d\nBooked seats:\t%3d\nCheck-ins:\t%3d", emptyCount, bookedCount, checkedInCount);

        txt_SeatSummary.setText(summary);
    }

    public Bitmap drawSeatTable(){
        //initialise table values
        int tableCellLength = getImageSize();
        Bitmap table = Bitmap.createBitmap(tableCellLength*seatColumn,tableCellLength*seatRow+1, Bitmap.Config.ARGB_8888);

        //initialise canvas and bitmap array
        Canvas canvas = new Canvas(table);
        Bitmap[][] bitmaps = new Bitmap[seatRow][seatColumn];
        for(int i = 0; i < seatRow; i++){
            for(int j = 0; j < seatColumn; j++) {
                switch(getStatusFromPreferences(i,j)){
                    case 0: bitmaps[i][j] = BitmapFactory.decodeResource(getResources(),R.drawable.empty); break;
                    case 1: bitmaps[i][j] = BitmapFactory.decodeResource(getResources(),R.drawable.booked); break;
                    case 2: bitmaps[i][j] = BitmapFactory.decodeResource(getResources(),R.drawable.checkedin); break;
                }
            }
        }

        //fill canvas
        for(int i = 0; i < seatRow; i++){
            for(int j = 0; j < seatColumn; j++) {
                canvas.drawBitmap(bitmaps[i][j], j*tableCellLength, i*tableCellLength, null);
            }
        }
        return table;
    }
    public int getImageSize(){
        Bitmap empty = BitmapFactory.decodeResource(getResources(),R.drawable.empty);

        return empty.getHeight();
    }
}
