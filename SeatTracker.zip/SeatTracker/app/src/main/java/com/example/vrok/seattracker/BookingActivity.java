package com.example.vrok.seattracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class BookingActivity extends ChangeStatusAbstract {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activityNo = STATUS_EMPTY;
        setBtn_ChangeStatus("Book Seat");
    }

    //sets status to booked (1)
    public void saveStatusToPreferences(int row, int column){
        mEditor.putInt("key_seat_status_row"+String.valueOf(row)+"_column_"+String.valueOf(column),STATUS_BOOKED);
    }

    @Override
    public void getIndividualSeatStatus() {
        status = getStatusFromPreferences(rowNo-1,seatNo-1);
        msgTitle = "Book seat?";
        msg = String.format("Seat %d in Row %d will be booked.",rowNo,seatNo);
        msgAccept = String.format("Booking at: Row %d Seat %d",rowNo,seatNo);
        msgBooked = String.format("Seat %d in Row %d is already booked.",rowNo,seatNo);
        msgCheckedIn = String.format("Seat %d in Row %d is checked-in.",rowNo,seatNo);
    }

    @Override
    public void getAllSeatsStatus() {
        msgTitle = "Book all seats?";
        msg = "This will set all seats to booked. Are you sure?";
        msgAccept = "All seats are set to booked.";
        msgBooked = "All seats are booked.";
        msgCheckedIn = "All seats checked-in.";
    }

    @Override
    public void getColumnSeatsStatus() {
        msgTitle = String.format("Book seats in Column %d?",seatNo);
        msg = String.format("This will set all seats in Column %d to booked.",seatNo);
        msgAccept = String.format("All seats in Column %d are set to booked.", seatNo);
        msgBooked = String.format("All seats in Column %d are already booked.",seatNo);
        msgCheckedIn = String.format("All seats in Column %d are checked-in.",seatNo);
    }

    @Override
    public void getRowSeatsStatus() {
        msgTitle = String.format("Book seats in Row %d?",rowNo);
        msg = String.format("This will set all seats in Row %d to booked.",rowNo);
        msgAccept = String.format("All seats in Row %d are set to booked.", rowNo);
        msgBooked = String.format("All seats in Row %d are already booked.",rowNo);
        msgCheckedIn = String.format("All seats in Row %d are checked-in.",rowNo);
    }

    @Override
    public boolean getStatusByActivity(int status) {return (status == STATUS_EMPTY);}

    @Override
    public void confirmMessage(AlertDialog.Builder alert) {
        switch (status){
            case 0: alert.show(); break;
            case 1: Toast.makeText(this,msgBooked,Toast.LENGTH_SHORT).show(); break;
            case 2: Toast.makeText(this,msgCheckedIn,Toast.LENGTH_SHORT).show(); break;
        }
    }

    public void btn_ChangeStatus_Clicked(View view){
        status = 0;
        super.btn_ChangeStatus_Clicked(view);
    }
}
