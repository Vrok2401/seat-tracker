package com.example.vrok.seattracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

public class SettingsActivity extends ActivityAbstract {
    private FrameLayout fragment_container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        fragment_container = (FrameLayout)findViewById(R.id.fragment_container);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SettingFragment()).commit();
    }

    @Override
    public void onBackPressed() {
        int newRow = Integer.parseInt(mPreferences.getString("key_row","5"));
        int newColumn = Integer.parseInt(mPreferences.getString("key_column","10"));
        if(newRow != seatRow){
            if(newRow > seatRow){
                for(int i = seatRow; i < newRow; i++) {
                    for(int j = 0; j < seatColumn; j++) {
                        mEditor.putInt("key_seat_status_row"+String.valueOf(i)+"_column_"+String.valueOf(j),0);
                    }
                }
            }
            else if(newRow < seatRow){
                for(int i = seatRow; i > newRow; i--) {
                    for(int j = 0; j < seatColumn; j++) {
                        mEditor.remove("key_seat_status_row" + String.valueOf(i-1) + "_column_" + String.valueOf(j));
                    }
                }
            }
        }
        if(newColumn != seatColumn){
            if(newColumn > seatColumn){
                for(int i = seatColumn; i < newColumn; i++){
                    for(int j = 0; j < seatRow; j++) {
                        mEditor.putInt("key_seat_status_row"+String.valueOf(j)+"_column_"+String.valueOf(i),0);
                    }
                }
            }
            else if(newColumn < seatColumn){
                for(int i = seatColumn; i > newColumn; i--){
                    for(int j = 0; j < seatRow; j++) {
                        mEditor.remove("key_seat_status_row" + String.valueOf(j) + "_column_" + String.valueOf(i-1));
                    }
                }
            }
        }
        mEditor.commit();
        super.onBackPressed();
    }
}
